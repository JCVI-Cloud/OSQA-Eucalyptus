$(function () {
    $('div#editor_side_bar').hide();

    $('#editor').focus(function(){ $('div#editor_side_bar').fadeIn('slow') });
    $('#editor').blur(function(){ $('div#editor_side_bar').fadeOut('slow') });
});
