import readers
import writers
import commands
import users
import meta
import auth
import admin

#from forum.modules.decorators import decorate_all

#decorate_all(readers)
#decorate_all(writers)
#decorate_all(commands)
#decorate_all(users)
#decorate_all(meta)
#decorate_all(auth)
#decorate_all(admin)
