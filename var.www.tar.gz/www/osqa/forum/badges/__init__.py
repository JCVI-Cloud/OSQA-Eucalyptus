from forum.modules import get_modules_script

get_modules_script('badges')

from base import BadgesMeta

